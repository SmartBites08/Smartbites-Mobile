# SmartBites Mobile

Versão React Native/Expo do SmartBites com a identidade visual verde-oliva da aplicação web: navegação inferior, despensa, receitas, IA Chef, relatórios, configurações e telas de acesso.

## Executar

Use Node.js 18 ou 20. Dentro desta pasta:

```bash
npm install
npx expo start
```

Abra o código QR no Expo Go ou execute em um simulador. O projeto usa Expo SDK 50 e React Native 0.73.6.

**Importante:** o login/cadastro e os dados são demonstrativos, mantidos apenas em memória. As informações voltam ao estado inicial ao reiniciar o app; não há autenticação real nem integração de IA. O arquivo `assets/` contém a identidade visual extraída da aplicação web fornecida.
