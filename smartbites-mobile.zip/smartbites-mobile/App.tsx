import React from 'react';
import { StatusBar } from 'react-native';
import { LayoutProvider } from './src/contexts/LayoutContext';
import { AlimentosProvider } from './src/contexts/AlimentosContext';
import { ReceitasProvider } from './src/contexts/ReceitasContext';
import { RootNavigator } from './src/navigation/RootNavigator';

export default function App() {
  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor="#FAF9F4" />
      <LayoutProvider>
        <AlimentosProvider>
          <ReceitasProvider>
            <RootNavigator />
          </ReceitasProvider>
        </AlimentosProvider>
      </LayoutProvider>
    </>
  );
}
