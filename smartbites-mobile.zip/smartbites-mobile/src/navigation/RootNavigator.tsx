import React, { useContext, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, Text, Pressable, ScrollView, Modal } from 'react-native';
import { LayoutContexto } from '../contexts/LayoutContext';
import { LoginScreen } from '../screens/LoginScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { DashboardScreen } from '../screens/DashboardScreen';
import { DespensaScreen, ReceitasScreen, IAChefScreen, RelatoriosScreen, ConfiguracoesScreen, SobreScreen } from '../screens/OtherScreens';
import { Brand, C, Icon } from '../theme/ui';

const Stack = createNativeStackNavigator();
const tabs = [
  { key: 'Dashboard', label: 'Visão geral', icon: 'home-outline' },
  { key: 'Despensa', label: 'Despensa', icon: 'file-tray-outline' },
  { key: 'Receitas', label: 'Receitas', icon: 'book-outline' },
  { key: 'IAChef', label: 'IA Chef', icon: 'restaurant-outline' },
  { key: 'Relatorios', label: 'Relatórios', icon: 'bar-chart-outline' },
  { key: 'Configuracoes', label: 'Configurações', icon: 'settings-outline' },
  { key: 'Sobre', label: 'Sobre', icon: 'leaf-outline' },
] as const;
function AppShell() {
  const [active, setActive] = useState<(typeof tabs)[number]['key']>('Dashboard');
  const [menu, setMenu] = useState(false);
  const { emailUsuarioContexto, setUsuarioLogadoContexto } = useContext(LayoutContexto);
  const views = { Dashboard: DashboardScreen, Despensa: DespensaScreen, Receitas: ReceitasScreen, IAChef: IAChefScreen, Relatorios: RelatoriosScreen, Configuracoes: ConfiguracoesScreen, Sobre: SobreScreen };
  const Current = views[active];
  const go = (key: typeof active) => { setActive(key); setMenu(false); };
  return <View style={{ flex: 1, backgroundColor: C.background }}>
    <View style={{ height: 68, backgroundColor: C.surface, borderBottomWidth: 1, borderColor: C.border, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
      <Brand compact /><View style={{ flexDirection: 'row', alignItems: 'center', gap: 18 }}><View style={{ backgroundColor: C.pale, borderRadius: 18, width: 34, height: 34, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: C.green, fontSize: 12, fontWeight: '800' }}>{emailUsuarioContexto.slice(0, 2).toUpperCase()}</Text></View><Pressable accessibilityLabel="Abrir menu" onPress={() => setMenu(true)}><Icon name="menu-outline" size={27} /></Pressable></View>
    </View>
    <Current navigation={{ navigate: go }} />
    <View style={{ flexDirection: 'row', backgroundColor: C.surface, borderTopWidth: 1, borderColor: C.border, paddingTop: 9, paddingBottom: 10 }}>
      {tabs.slice(0, 5).map(tab => <Pressable key={tab.key} accessibilityRole="tab" accessibilityState={{ selected: active === tab.key }} onPress={() => go(tab.key)} style={{ width: '20%', minHeight: 51, alignItems: 'center', justifyContent: 'center', gap: 4, borderTopWidth: active === tab.key ? 2 : 0, borderColor: C.green }}><Icon name={tab.icon} size={22} color={active === tab.key ? C.green : C.muted} /><Text style={{ fontSize: 10, fontWeight: active === tab.key ? '700' : '500', color: active === tab.key ? C.green : C.muted }}>{tab.label}</Text></Pressable>)}
    </View>
    <Modal visible={menu} transparent animationType="fade" onRequestClose={() => setMenu(false)}><Pressable onPress={() => setMenu(false)} style={{ flex: 1, backgroundColor: 'rgba(27,37,20,0.5)', justifyContent: 'flex-end' }}><Pressable onPress={() => {}} style={{ backgroundColor: C.surface, padding: 22, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 18 }}><Text style={{ fontSize: 21, color: C.ink, fontWeight: '800' }}>Menu</Text><Pressable onPress={() => setMenu(false)} accessibilityLabel="Fechar menu"><Icon name="close" /></Pressable></View><ScrollView style={{ maxHeight: 470 }}>{tabs.map(tab => <Pressable key={tab.key} onPress={() => go(tab.key)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 12 }}><Icon name={tab.icon} color={active === tab.key ? C.green : C.muted} /><Text style={{ color: active === tab.key ? C.green : C.ink, fontWeight: '600' }}>{tab.label}</Text></Pressable>)}<Pressable onPress={() => { setMenu(false); setUsuarioLogadoContexto(false); }} style={{ flexDirection: 'row', gap: 12, paddingVertical: 16 }}><Icon name="log-out-outline" color={C.red} /><Text style={{ color: C.red, fontWeight: '700' }}>Sair</Text></Pressable></ScrollView></Pressable></Pressable></Modal>
  </View>;
}
export function RootNavigator() {
  const { usuarioLogadoContexto } = useContext(LayoutContexto);
  return <NavigationContainer>{usuarioLogadoContexto ? <AppShell /> : <Stack.Navigator screenOptions={{ headerShown: false }}><Stack.Screen name="Login" component={LoginScreen} /><Stack.Screen name="Register" component={RegisterScreen} /></Stack.Navigator>}</NavigationContainer>;
}
