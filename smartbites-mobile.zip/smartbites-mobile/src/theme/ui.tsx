import React from 'react';
import { Image, Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export const C = {
  background: '#FAF9F4', surface: '#FFFFFF', ink: '#252A20', muted: '#72776A',
  forest: '#26321B', green: '#344D0A', pale: '#E5EED8', border: '#E2DED3',
  amber: '#FFF0CE', amberInk: '#93550C', red: '#BB483E', redPale: '#FBEAE7',
  bluePale: '#DDF3F2', blue: '#147976',
};
export const S = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background }, scroll: { paddingHorizontal: 20, paddingTop: 26, paddingBottom: 110 },
  eyebrow: { color: C.green, fontSize: 11, fontWeight: '800', letterSpacing: 1.3, textTransform: 'uppercase' },
  h1: { color: C.ink, fontSize: 29, fontWeight: '800', marginTop: 5, lineHeight: 35 },
  sub: { color: C.muted, fontSize: 14, lineHeight: 21, marginTop: 5 },
  h2: { color: C.ink, fontSize: 19, fontWeight: '800' },
  card: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 8 },
  fieldLabel: { color: C.ink, fontSize: 12, fontWeight: '700', marginBottom: 7 },
  input: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 6, height: 48, paddingHorizontal: 13, color: C.ink, fontSize: 15 },
});
export function Icon({ name, size = 21, color = C.ink }: { name: React.ComponentProps<typeof Ionicons>['name']; size?: number; color?: string }) {
  return <Ionicons name={name} size={size} color={color} />;
}
export function HeaderText({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return <View style={{ marginBottom: 21 }}><Text style={S.eyebrow}>{eyebrow}</Text><Text style={S.h1}>{title}</Text><Text style={S.sub}>{subtitle}</Text></View>;
}
export function SectionTitle({ title, action, onPress }: { title: string; action?: string; onPress?: () => void }) {
  return <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 26, marginBottom: 14, gap: 10 }}><Text style={[S.h2, { flexShrink: 1 }]}>{title}</Text>{action && onPress && <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', gap: 5, alignItems: 'center' }}><Text style={{ color: C.green, fontSize: 13, fontWeight: '700' }}>{action}</Text><Icon name="arrow-forward" size={16} color={C.green} /></Pressable>}</View>;
}
export function Action({ title, onPress, secondary = false, icon, style }: { title: string; onPress: () => void; secondary?: boolean; icon?: React.ComponentProps<typeof Ionicons>['name']; style?: ViewStyle }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={[{ minHeight: 38, paddingHorizontal: 14, borderRadius: 6, backgroundColor: secondary ? C.surface : C.green, borderWidth: secondary ? 1 : 0, borderColor: C.border, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7 }, style]}>{icon && <Icon name={icon} size={17} color={secondary ? C.green : C.surface} />}<Text style={{ color: secondary ? C.green : C.surface, fontSize: 13, fontWeight: '700' }}>{title}</Text></Pressable>;
}
export function FoodIcon({ name, recipe = false }: { name: string; recipe?: boolean }) {
  const icons: Record<string, React.ComponentProps<typeof Ionicons>['name']> = { Tomate: 'nutrition-outline', Alface: 'leaf-outline', Cenoura: 'nutrition-outline', Batata: 'nutrition-outline', Ovos: 'ellipse-outline', Frango: 'restaurant-outline', Leite: 'water-outline', Queijo: 'cube-outline', Pão: 'fast-food-outline', Arroz: 'restaurant-outline', 'Salada Fresca': 'leaf-outline', 'Omelete de Vegetais': 'restaurant-outline', 'Arroz com Frango': 'restaurant-outline', 'Sopa de Legumes': 'restaurant-outline', 'Frittata Italiana': 'restaurant-outline' };
  return <View style={{ width: 46, height: 46, backgroundColor: C.background, borderRadius: 7, alignItems: 'center', justifyContent: 'center' }}><Icon name={icons[name] || (recipe ? 'restaurant-outline' : 'cube-outline')} size={24} /></View>;
}
export function Brand({ compact = false }: { compact?: boolean }) {
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}><Image source={require('../../assets/logo.png')} style={{ width: compact ? 30 : 44, height: compact ? 30 : 44, borderRadius: 7 }} resizeMode="cover" /><Text style={{ fontSize: compact ? 20 : 24, fontWeight: '800', color: C.ink }}>SmartBites</Text></View>;
}
export function daysUntil(date: string) { return Math.ceil((new Date(date.slice(0, 10) + 'T23:59:59').getTime() - Date.now()) / 86400000); }
export function dayLabel(days: number) { return days < 0 ? 'Vencido' : days === 0 ? 'Hoje' : days === 1 ? 'Amanhã' : `${days} dias`; }
