import React, { useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import { LayoutContexto } from '../contexts/LayoutContext';

const MENU_ITEMS = [
  { rotulo: 'Visão Geral', icone: '📊', rota: 'Dashboard' },
  { rotulo: 'Minha Despensa', icone: '🥬', rota: 'Despensa' },
  { rotulo: 'Receitas', icone: '🍳', rota: 'Receitas' },
  { rotulo: 'IA Chef', icone: '🤖', rota: 'IAChef' },
  { rotulo: 'Relatórios', icone: '📈', rota: 'Relatorios' },
  { rotulo: 'Configurações', icone: '⚙️', rota: 'Configuracoes' },
  { rotulo: 'Sobre', icone: 'ℹ️', rota: 'Sobre' },
];

export function DrawerMenu({ navigation }: any) {
  const { emailUsuarioContexto, setUsuarioLogadoContexto } = useContext(LayoutContexto);

  const iniciais = emailUsuarioContexto
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase();

  const handleLogout = () => {
    Alert.alert('Sair', 'Tem certeza que deseja sair?', [
      { text: 'Cancelar' },
      {
        text: 'Sair',
        onPress: () => {
          setUsuarioLogadoContexto(false);
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>🥬</Text>
        <Text style={styles.logoTexto}>SmartBites</Text>
      </View>

      <ScrollView style={styles.menu}>
        {MENU_ITEMS.map((item) => (
          <TouchableOpacity
            key={item.rota}
            style={styles.menuItem}
            onPress={() => {
              navigation.navigate(item.rota);
              navigation.closeDrawer();
            }}
          >
            <Text style={styles.menuIcone}>{item.icone}</Text>
            <Text style={styles.menuLabel}>{item.rotulo}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.usuarioSection}>
          <View style={styles.avatar}>
            <Text style={styles.avatarTexto}>{iniciais}</Text>
          </View>
          <Text style={styles.usuarioNome} numberOfLines={1}>
            {emailUsuarioContexto}
          </Text>
        </View>

        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutTexto}>🚪 Sair</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    backgroundColor: '#4CAF50',
    paddingVertical: 20,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  logo: {
    fontSize: 32,
    marginBottom: 8,
  },
  logoTexto: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFF',
  },
  menu: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 4,
    borderRadius: 8,
    backgroundColor: '#F8F8F8',
  },
  menuIcone: {
    fontSize: 20,
    marginRight: 12,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: '#EEE',
    paddingVertical: 16,
    paddingHorizontal: 12,
  },
  usuarioSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarTexto: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '700',
  },
  usuarioNome: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  logoutBtn: {
    backgroundColor: '#FFE8E8',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  logoutTexto: {
    color: '#F44336',
    fontSize: 14,
    fontWeight: '600',
  },
});
