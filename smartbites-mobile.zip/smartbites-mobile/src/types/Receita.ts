export interface Receita {
  id: string;
  titulo: string;
  emoji: string;
  tempoPreparo: string;
  porcoes: string;
  tags: string[];
  comIA: boolean;
}
