export interface Alimento {
  id: string;
  nome: string;
  emoji: string;
  quantidade: number;
  unidade: string;
  local: 'Geladeira' | 'Congelador' | 'Despensa';
  dataValidade: string;
}
