import React, { useContext } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { AlimentosContexto } from '../contexts/AlimentosContext';
import { ReceitasContexto } from '../contexts/ReceitasContext';
import { Action, C, dayLabel, daysUntil, FoodIcon, HeaderText, Icon, S, SectionTitle } from '../theme/ui';

export function DashboardScreen({ navigation }: any) {
  const { alimentosContexto: foods } = useContext(AlimentosContexto);
  const { receitasContexto: recipes } = useContext(ReceitasContexto);
  const { width } = useWindowDimensions();
  const near = foods.filter(f => daysUntil(f.dataValidade) >= 0 && daysUntil(f.dataValidade) <= 3).length;
  const expired = foods.filter(f => daysUntil(f.dataValidade) < 0).length;
  const stats = [
    { n: foods.length, label: 'Itens na despensa', icon: 'file-tray-outline', bg: C.pale, ink: C.green },
    { n: near, label: 'Vencem em breve', icon: 'time-outline', bg: C.amber, ink: C.amberInk },
    { n: expired, label: 'Já vencidos', icon: 'warning-outline', bg: C.redPale, ink: C.red },
    { n: recipes.length, label: 'Receitas salvas', icon: 'book-outline', bg: C.bluePale, ink: C.blue },
  ] as const;
  return <ScrollView style={S.page} contentContainerStyle={S.scroll}>
    <HeaderText eyebrow="Sua cozinha, em dia" title="Visão geral" subtitle="Tudo o que importa na sua despensa, em um só lugar." />
    {near > 0 && <View style={{ backgroundColor: C.amber, padding: 14, borderRadius: 7, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 22 }}><Icon name="warning-outline" color={C.amberInk} size={19} /><Text style={{ color: C.amberInk, fontSize: 13, fontWeight: '700', flex: 1 }}>{near} {near === 1 ? 'alimento vence' : 'alimentos vencem'} nos próximos 3 dias.</Text></View>}
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 11 }}>{stats.map(s => <View key={s.label} style={[S.card, { width: (width - 51) / 2, minHeight: 135, padding: 17, justifyContent: 'space-between' }]}><View style={{ backgroundColor: s.bg, width: 35, height: 35, alignItems: 'center', justifyContent: 'center', borderRadius: 7 }}><Icon name={s.icon} size={19} color={s.ink} /></View><View><Text style={{ fontSize: 29, fontWeight: '800', color: C.ink }}>{s.n}</Text><Text style={{ color: C.muted, fontSize: 12 }}>{s.label}</Text></View></View>)}</View>
    <SectionTitle title="Itens recentes" action="Ver despensa" onPress={() => navigation.navigate('Despensa')} />
    <View style={[S.card, { paddingHorizontal: 18 }]}>{foods.slice(0, 5).map((f, i) => <View key={f.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 13, gap: 11, borderBottomWidth: i < Math.min(foods.length, 5) - 1 ? 1 : 0, borderColor: C.border }}><FoodIcon name={f.nome} /><View style={{ flex: 1 }}><Text style={{ color: C.ink, fontWeight: '700', fontSize: 14 }}>{f.nome}</Text><Text style={{ color: C.muted, fontSize: 12, marginTop: 3 }}>{f.quantidade} {f.unidade} · {f.local}</Text></View><Text style={{ color: daysUntil(f.dataValidade) <= 3 ? C.red : C.green, fontWeight: '700', fontSize: 12 }}>{dayLabel(daysUntil(f.dataValidade))}</Text></View>)}{foods.length === 0 && <Text style={{ color: C.muted, paddingVertical: 25 }}>Sua despensa está vazia.</Text>}</View>
    <SectionTitle title="Inspiração para hoje" /><View style={{ backgroundColor: C.forest, borderRadius: 8, padding: 23, minHeight: 215 }}><Text style={{ color: C.surface, fontSize: 11, fontWeight: '800' }}>✦ IA CHEF</Text><Text style={{ color: C.surface, fontWeight: '800', fontSize: 23, marginTop: 19 }}>O que vamos cozinhar?</Text><Text style={{ color: C.pale, fontSize: 13, lineHeight: 20, marginVertical: 9 }}>Encontre uma ideia gostosa para aproveitar o que você já tem.</Text><Action title="Explorar receitas" onPress={() => navigation.navigate('IAChef')} style={{ alignSelf: 'flex-start', backgroundColor: C.pale, marginTop: 10 }} secondary /></View>
  </ScrollView>;
}
