import React, { createContext, useState, ReactNode } from 'react';
import { Alimento } from '../types/Alimento';
import { alimentosMock } from '../services/dadosMock';

interface AlimentosContextType {
  alimentosContexto: Alimento[];
  setAlimentosContexto: (alimentos: Alimento[]) => void;
  adicionarAlimento: (alimento: Alimento) => void;
  atualizarAlimento: (id: string, alimento: Alimento) => void;
  deletarAlimento: (id: string) => void;
}

export const AlimentosContexto = createContext<AlimentosContextType>({
  alimentosContexto: alimentosMock,
  setAlimentosContexto: () => {},
  adicionarAlimento: () => {},
  atualizarAlimento: () => {},
  deletarAlimento: () => {},
});

interface AlimentosProviderProps {
  children: ReactNode;
}

export function AlimentosProvider({ children }: AlimentosProviderProps) {
  const [alimentosContexto, setAlimentosContexto] = useState<Alimento[]>(alimentosMock);

  const adicionarAlimento = (alimento: Alimento) => {
    setAlimentosContexto([...alimentosContexto, { ...alimento, id: Date.now().toString() }]);
  };

  const atualizarAlimento = (id: string, alimento: Alimento) => {
    setAlimentosContexto(
      alimentosContexto.map(a => (a.id === id ? { ...alimento, id } : a))
    );
  };

  const deletarAlimento = (id: string) => {
    setAlimentosContexto(alimentosContexto.filter(a => a.id !== id));
  };

  return (
    <AlimentosContexto.Provider
      value={{
        alimentosContexto,
        setAlimentosContexto,
        adicionarAlimento,
        atualizarAlimento,
        deletarAlimento,
      }}
    >
      {children}
    </AlimentosContexto.Provider>
  );
}
