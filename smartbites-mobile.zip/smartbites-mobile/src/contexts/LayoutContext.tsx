import React, { createContext, useState, ReactNode } from 'react';

interface LayoutContextType {
  menuAbertoContexto: boolean;
  setMenuAbertoContexto: (state: boolean) => void;
  emailUsuarioContexto: string;
  setEmailUsuarioContexto: (email: string) => void;
  usuarioLogadoContexto: boolean;
  setUsuarioLogadoContexto: (state: boolean) => void;
}

export const LayoutContexto = createContext<LayoutContextType>({
  menuAbertoContexto: false,
  setMenuAbertoContexto: () => {},
  emailUsuarioContexto: 'Usuário',
  setEmailUsuarioContexto: () => {},
  usuarioLogadoContexto: false,
  setUsuarioLogadoContexto: () => {},
});

interface LayoutProviderProps {
  children: ReactNode;
}

export function LayoutProvider({ children }: LayoutProviderProps) {
  const [menuAbertoContexto, setMenuAbertoContexto] = useState(false);
  const [emailUsuarioContexto, setEmailUsuarioContexto] = useState('Usuário');
  const [usuarioLogadoContexto, setUsuarioLogadoContexto] = useState(false);

  return (
    <LayoutContexto.Provider
      value={{
        menuAbertoContexto,
        setMenuAbertoContexto,
        emailUsuarioContexto,
        setEmailUsuarioContexto,
        usuarioLogadoContexto,
        setUsuarioLogadoContexto,
      }}
    >
      {children}
    </LayoutContexto.Provider>
  );
}
