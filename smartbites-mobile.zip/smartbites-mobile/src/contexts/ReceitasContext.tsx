import React, { createContext, useState, ReactNode } from 'react';
import { Receita } from '../types/Receita';
import { receitasMock } from '../services/dadosMock';

interface ReceitasContextType {
  receitasContexto: Receita[];
  setReceitasContexto: (receitas: Receita[]) => void;
  adicionarReceita: (receita: Receita) => void;
  atualizarReceita: (id: string, receita: Receita) => void;
  deletarReceita: (id: string) => void;
}

export const ReceitasContexto = createContext<ReceitasContextType>({
  receitasContexto: receitasMock,
  setReceitasContexto: () => {},
  adicionarReceita: () => {},
  atualizarReceita: () => {},
  deletarReceita: () => {},
});

interface ReceitasProviderProps {
  children: ReactNode;
}

export function ReceitasProvider({ children }: ReceitasProviderProps) {
  const [receitasContexto, setReceitasContexto] = useState<Receita[]>(receitasMock);

  const adicionarReceita = (receita: Receita) => {
    setReceitasContexto([...receitasContexto, { ...receita, id: Date.now().toString() }]);
  };

  const atualizarReceita = (id: string, receita: Receita) => {
    setReceitasContexto(
      receitasContexto.map(r => (r.id === id ? { ...receita, id } : r))
    );
  };

  const deletarReceita = (id: string) => {
    setReceitasContexto(receitasContexto.filter(r => r.id !== id));
  };

  return (
    <ReceitasContexto.Provider
      value={{
        receitasContexto,
        setReceitasContexto,
        adicionarReceita,
        atualizarReceita,
        deletarReceita,
      }}
    >
      {children}
    </ReceitasContexto.Provider>
  );
}
